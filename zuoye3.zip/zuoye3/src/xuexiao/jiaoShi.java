package xuexiao;

public class jiaoShi extends renYuan{
    void suoShouKeCheng(int y){
        if(y == 11){
            System.out.println("，教授课程:高等数学");
        }else if(y == 12){
            System.out.println("，教授课程:JAVA");
        }
    }
}
